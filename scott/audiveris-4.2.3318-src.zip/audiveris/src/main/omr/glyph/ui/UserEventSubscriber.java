/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package omr.glyph.ui;

import omr.selection.UserEvent;

import org.bushe.swing.event.EventSubscriber;

/**
 * Class {@code UserEventSubscriber}
 *
 * @author Hervé Bitteur
 */
public interface UserEventSubscriber
    extends EventSubscriber<UserEvent>
{
}
